#!/bin/sh
vcom registerfile.vhd tb_registerfile.vhd
