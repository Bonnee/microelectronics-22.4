#! /bin/env bash
source /software/scripts/init_questa10.7c
vcom RF.vhd tb_registerfile.vhd
