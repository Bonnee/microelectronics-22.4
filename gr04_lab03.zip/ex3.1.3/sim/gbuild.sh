#! /bin/sh
ghdl analyze COMM_PKG.vhd RF.vhd WRF_CU.vhd ADDR_DEC.vhd
