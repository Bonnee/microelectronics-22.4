#! /bin/env bash
source /software/scripts/init_synopsys_64.11
design_vision -no_gui -f WRF_t.scr
