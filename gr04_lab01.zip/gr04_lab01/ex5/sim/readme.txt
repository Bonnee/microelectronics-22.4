Q1
What can you do to solve the problem?
A1
Lorem ipsum

Q2
Which is the difference among the three output “S1”, “S2”, “S3”?
A2
Lorem ipsum

Q3
Zoom the waves in the range 24.5ns - 24.6ns: what’s happening to the three outputs?
A3
In the output of adder with delay (S2) the carry propagation is visible, that results in the overflow of the addition.
Lorem ipsum
