#!/bin/sh
vcom constants.vhd fd.vhd reg.vhd tb_reg.vhd

