#!/bin/bash
source /software/scripts/init_questa10.7c 
vcom constants.vhd iv.vhd nd2.vhd mux21.vhd mux21_generic.vhd tb_mux21_generic.vhd
