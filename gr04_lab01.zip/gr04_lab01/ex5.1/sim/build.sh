#!/bin/sh
vcom constants.vhd fa.vhd lfsr.vhd rca.vhd rca_generic.vhd tb_rca_generic.vhd
