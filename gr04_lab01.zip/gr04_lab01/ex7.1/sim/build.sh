#!/bin/bash
source /software/scripts/init_questa10.7c 
vcom constants.vhd alu_type.vhd alu.vhd tb_alu.vhd
