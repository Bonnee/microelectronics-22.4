#!/bin/sh
vcom constants.vhd fa.vhd rca.vhd rca_generic.vhd
