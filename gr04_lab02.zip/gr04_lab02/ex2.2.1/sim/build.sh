#!/bin/sh
vcom fa.vhd rca.vhd boothenc.vhd boothmul.vhd tb_multiplier.vhd 
