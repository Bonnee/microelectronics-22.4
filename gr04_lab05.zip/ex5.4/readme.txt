Q3 : What happens to the values of delay and power dissipation? Check the output measure and analyze
     the advantages and disadvantages in using the two gates.

A3:  With little load, both NAND and NANDX8 achieve similar timing
     characteristics. The big difference lies in the power consumption, wich is
     considerably lower in NAND, when compared to NANDX8.  When applying bigger
     loads, the timing of NAND degrades, while NANDX8 maintains a better overall
     timing performance, while retaining the previous disadvantage in power 
     consumption.