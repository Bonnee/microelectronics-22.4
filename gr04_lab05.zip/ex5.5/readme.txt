Q4: Compare these results with those obtained from the two previous gates, as well by superposing the four
    waveforms. What’s happening to the delay? What about the current? Which is the percentage of
    advantage and/or disadvantage in using the LL gates with respect to the HS ones?

A4: There are a differences in power and delay that amount to 20% between HS and LL circuit.
    Obviously in LL the consumption is lower and, as a result, the delay is larger.