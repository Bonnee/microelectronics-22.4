Q1: Sketch on paper the NAND sub-circuit, expressing the names of the internal nodes and neglecting the
    other parameters. Draw also the external structure which calls the sub-circuit with the node names.
    Note the definition of the input waveform and the use of the .measure instruction: what does it
    perform?

A1: The .measure instruction measures the time a certain waveform takes to rise/fall to a certain trigger value (VAL).

