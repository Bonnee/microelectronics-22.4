FFDH
	violations happen when offset values are in the interval 3.8e-10 to 4.0e-10
	for he HL transition. For the LH transition, the offset interval is 3.5e-10
	to 4.0e-10.

	CPI signal is disturbed in proximity of the rising edge and, as a
	consequence, CPN is disturbed in the falling edge.  When D is set outside
	the positive CPI window, Q is not updated. If M changes too early, Q is not
	updated.

FFDSU
	violations happen when offset values are in the interval 1.6e-10 to 4.0e-10
	for he HL transition. For the LH transition, the offset interval is 1.4e-10
	to 4.0e-10.

	Generally speaking, the considerations made for FFDH also apply to FFDSU.
	CPI signal is disturbed in proximity of the rising edge and, as a
	consequence, CPN is disturbed in the falling edge.  When D is set outside
	the positive CPI window, Q is not updated. If M changes too early, Q is not
	updated.
